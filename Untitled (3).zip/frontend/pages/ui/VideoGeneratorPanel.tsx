import { useState } from 'react'
import { ChevronDown, ChevronUp, Clapperboard, Film, Loader2, Play, Sparkles, Video } from 'lucide-react'
import { useGenerateVideoScript } from '../../hooks/backend/video'
import { Badge } from '../../lib/shadcn/badge'
import { Button } from '../../lib/shadcn/button'
import { Input } from '../../lib/shadcn/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../lib/shadcn/select'
import type { VideoScript } from '../../../backend/video/generateVideoScript'

type Style = 'cinematic' | 'educational' | 'animated' | 'documentary'
type Duration = '30s' | '60s' | '90s' | '3min'

const MOOD_COLORS: Record<string, string> = {
  Energetic:   'bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400',
  Vibrant:     'bg-purple-100 text-purple-700 dark:bg-purple-950/40 dark:text-purple-400',
  Thrilling:   'bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400',
  Mysterious:  'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-400',
  Calm:        'bg-teal-100 text-teal-700 dark:bg-teal-950/40 dark:text-teal-400',
  Hopeful:     'bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400',
  Dramatic:    'bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400',
  Playful:     'bg-yellow-100 text-yellow-700 dark:bg-yellow-950/40 dark:text-yellow-400',
}

function getMoodColor(mood: string) {
  return MOOD_COLORS[mood] ?? 'bg-secondary text-secondary-foreground'
}

type Props = {
  isExpanded: boolean
  onToggle: () => void
}

export default function VideoGeneratorPanel({ isExpanded, onToggle }: Props) {
  const [prompt, setPrompt] = useState('')
  const [style, setStyle] = useState<Style>('cinematic')
  const [duration, setDuration] = useState<Duration>('60s')
  const [script, setScript] = useState<VideoScript | null>(null)
  const [activeScene, setActiveScene] = useState(0)

  const { trigger: generate, loading } = useGenerateVideoScript()

  const handleGenerate = async () => {
    if (!prompt.trim() || loading) return
    const result = await generate({ prompt: prompt.trim(), style, duration })
    if (result) {
      setScript(result as VideoScript)
      setActiveScene(0)
    }
  }

  return (
    <div className="border-t border-b border-border bg-card shrink-0">
      {/* Header bar — always visible */}
      <button
        onClick={onToggle}
        className="flex w-full items-center gap-3 px-4 py-2.5 hover:bg-accent/50 transition-colors"
      >
        <div className="flex h-6 w-6 items-center justify-center rounded-md bg-primary/10">
          <Video className="h-3.5 w-3.5 text-primary" />
        </div>
        <span className="text-sm font-semibold text-foreground">AI Video Generator</span>
        {script && (
          <Badge variant="secondary" className="text-xs gap-1 ml-1">
            <Film className="h-3 w-3" />{script.scenes.length} scenes
          </Badge>
        )}
        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Prompt → Storyboard</span>
          {isExpanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
        </div>
      </button>

      {/* Expanded content */}
      {isExpanded && (
        <div className="border-t border-border">
          {/* Prompt row */}
          <div className="flex items-center gap-2 px-4 py-3 bg-background/50">
            <Input
              placeholder="Describe your video idea… e.g. 'A sunrise timelapse over mountain peaks'"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleGenerate() }}
              className="flex-1 text-sm"
            />
            <Select value={style} onValueChange={(v) => setStyle(v as Style)}>
              <SelectTrigger className="w-[130px] text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cinematic">🎬 Cinematic</SelectItem>
                <SelectItem value="educational">📚 Educational</SelectItem>
                <SelectItem value="animated">✨ Animated</SelectItem>
                <SelectItem value="documentary">🎥 Documentary</SelectItem>
              </SelectContent>
            </Select>
            <Select value={duration} onValueChange={(v) => setDuration(v as Duration)}>
              <SelectTrigger className="w-[90px] text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30s">30s</SelectItem>
                <SelectItem value="60s">60s</SelectItem>
                <SelectItem value="90s">90s</SelectItem>
                <SelectItem value="3min">3 min</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleGenerate} disabled={!prompt.trim() || loading} size="sm" className="gap-1.5 shrink-0">
              {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
              {loading ? 'Generating…' : 'Generate'}
            </Button>
          </div>

          {/* Storyboard result */}
          {script && (
            <div className="px-4 pb-4">
              {/* Video title + meta */}
              <div className="mb-3 flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Clapperboard className="h-4 w-4 text-primary" />
                  <span className="text-sm font-bold text-foreground">{script.title}</span>
                </div>
                <Badge variant="outline" className="text-xs">{script.style}</Badge>
                <Badge variant="outline" className="text-xs">{script.totalDuration}</Badge>
                <div className="ml-auto text-xs text-muted-foreground italic">"{script.hook}"</div>
              </div>

              {/* Scene filmstrip */}
              <div className="flex gap-2 overflow-x-auto pb-2 snap-x">
                {script.scenes.map((scene, idx) => (
                  <button
                    key={scene.sceneNumber}
                    onClick={() => setActiveScene(idx)}
                    className={`snap-start shrink-0 w-52 rounded-lg border text-left transition-all ${activeScene === idx ? 'border-primary bg-primary/5 shadow-sm' : 'border-border bg-background hover:border-primary/50 hover:bg-accent/30'}`}
                  >
                    {/* Scene thumbnail placeholder */}
                    <div className="relative h-24 w-full rounded-t-lg overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900 dark:from-slate-900 dark:to-slate-950 flex items-center justify-center">
                      <div className="absolute inset-0 opacity-20" style={{ background: `radial-gradient(circle at 50% 50%, hsl(var(--primary)) 0%, transparent 70%)` }} />
                      <div className="relative text-center">
                        <Play className="h-6 w-6 text-white/70 mx-auto mb-1" />
                        <span className="text-[10px] text-white/60 font-mono">{scene.duration}</span>
                      </div>
                      <div className="absolute bottom-1.5 left-2 text-[10px] font-bold text-white/80">
                        #{scene.sceneNumber}
                      </div>
                      <div className="absolute top-1.5 right-2">
                        <span className={`rounded-full px-1.5 py-0.5 text-[9px] font-semibold ${getMoodColor(scene.mood)}`}>{scene.mood}</span>
                      </div>
                    </div>
                    <div className="p-2">
                      <p className="text-[11px] font-semibold text-foreground truncate">{scene.title}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{scene.cameraAngle}</p>
                    </div>
                  </button>
                ))}
              </div>

              {/* Active scene detail */}
              {script.scenes[activeScene] && (() => {
                const scene = script.scenes[activeScene]!
                return (
                  <div className="mt-3 grid grid-cols-2 gap-3 rounded-lg border border-border bg-background p-3">
                    <div>
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Visual</p>
                      <p className="text-xs text-foreground leading-relaxed">{scene.visualDescription}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Narration</p>
                      <p className="text-xs text-foreground leading-relaxed italic">"{scene.narration}"</p>
                      <div className="mt-2 flex gap-1.5">
                        <Badge variant="secondary" className="text-[10px]">{scene.cameraAngle}</Badge>
                        <Badge variant="secondary" className="text-[10px]">{scene.duration}</Badge>
                      </div>
                    </div>
                  </div>
                )
              })()}

              {/* CTA */}
              <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                <span className="font-medium text-foreground">CTA:</span>
                <span className="italic">"{script.callToAction}"</span>
              </div>
            </div>
          )}

          {/* Empty state */}
          {!script && !loading && (
            <div className="flex items-center justify-center gap-2 py-5 text-muted-foreground">
              <Film className="h-4 w-4" />
              <span className="text-xs">Enter a prompt above and click Generate to create your storyboard</span>
            </div>
          )}

          {loading && (
            <div className="flex items-center justify-center gap-2 py-5 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin text-primary" />
              <span className="text-xs">Crafting your storyboard scenes…</span>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
