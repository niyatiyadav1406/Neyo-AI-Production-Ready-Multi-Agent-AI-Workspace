import { generateModelText, getModelConfig } from '../assistant/shared'

type Params = {
  message: string
  topic: string
  history: Array<{ role: 'user' | 'assistant'; content: string }>
  level: 'beginner' | 'intermediate' | 'advanced'
}

export type TutorResponse = {
  reply: string
  followUpQuestions: string[]
  keyPoints: string[]
  difficulty: string
}

const MOCK_RESPONSE: TutorResponse = {
  reply: 'Great question! This is a fundamental concept. Think of it like a recipe — you define the steps once and can use them anywhere. When you call a function, it executes those steps with the values you provide.',
  followUpQuestions: ['Can you give me a real-world example?', 'How does this relate to scope?', 'What are best practices here?'],
  keyPoints: ['Reusability reduces code duplication', 'Functions accept inputs and return outputs', 'Proper naming makes code self-documenting'],
  difficulty: 'beginner',
}

export default async function chatTutor(req: { params: Params }) {
  const { message, topic, level, history } = req.params
  const model = getModelConfig()

  const historyContext = history
    .slice(-6)
    .map((h) => `${h.role === 'user' ? 'Student' : 'Tutor'}: ${h.content}`)
    .join('\n')

  const instruction = `${historyContext ? `Previous conversation:\n${historyContext}\n\n` : ''}Student asks: "${message}"

You are teaching ${topic} to a ${level} student. Respond with pure JSON only:
{
  "reply": "Your clear, friendly explanation with examples (2-3 paragraphs). Use analogies suitable for ${level} level.",
  "followUpQuestions": ["Question to deepen understanding?", "Another follow-up?", "Third question?"],
  "keyPoints": ["Key concept 1", "Key concept 2", "Key concept 3"],
  "difficulty": "${level}"
}`

  const raw = await generateModelText({
    model,
    instruction,
    systemMessage: `You are an expert, encouraging AI Tutor specializing in ${topic}. Explain at ${level} level. Respond only with valid JSON.`,
    temperature: 0.7,
    mockResponse: JSON.stringify(MOCK_RESPONSE),
  })

  try {
    const cleaned = raw.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
    return JSON.parse(cleaned) as TutorResponse
  } catch {
    return MOCK_RESPONSE
  }
}
