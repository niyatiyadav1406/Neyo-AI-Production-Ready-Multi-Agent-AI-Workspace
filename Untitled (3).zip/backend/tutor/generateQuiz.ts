import {
  generateModelText,
  getModelConfig,
  summarizeText,
} from '../assistant/shared'

type Params = {
  topic: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  numQuestions?: number
  modelId?: string
}

export type QuizQuestion = {
  id: string
  question: string
  options: string[]
  correctIndex: number
  explanation: string
  subtopic: string
}

export type GenerateQuizResult = {
  questions: QuizQuestion[]
  topic: string
  difficulty: string
}

export default async function generateQuiz(
  req: { params: Params },
): Promise<GenerateQuizResult> {
  const { topic, difficulty, numQuestions = 5, modelId } = req.params
  const model = getModelConfig(modelId)
  const count = Math.min(Math.max(numQuestions ?? 5, 1), 8)

  const instruction = `Generate exactly ${count} multiple-choice quiz questions about "${topic}" at ${difficulty} level.

Return ONLY a valid JSON array (no markdown, no code blocks, no extra text):
[
  {
    "question": "...",
    "options": ["A) ...", "B) ...", "C) ...", "D) ..."],
    "correctIndex": 0,
    "explanation": "Brief 1-2 sentence explanation of the correct answer.",
    "subtopic": "Specific concept tested"
  }
]

Rules:
- correctIndex is 0-based (0=A, 1=B, 2=C, 3=D)
- All 4 options must be plausible distractors
- Each question covers a distinct aspect of ${topic}
- Difficulty is strictly ${difficulty}`

  const mockData: QuizQuestion[] = [
    {
      id: 'q-0',
      question: `What is the primary purpose of ${topic}?`,
      options: ['A) Data storage', 'B) Code organization and execution', 'C) Network communication', 'D) UI rendering'],
      correctIndex: 1,
      explanation: `${topic} focuses on code organization and execution, enabling structured and maintainable programs.`,
      subtopic: `${topic} basics`,
    },
    {
      id: 'q-1',
      question: `Which concept is fundamental to ${topic} at ${difficulty} level?`,
      options: ['A) Variables and scope', 'B) Database schemas', 'C) HTTP protocols', 'D) CSS selectors'],
      correctIndex: 0,
      explanation: 'Variables and scope are foundational in any programming context, controlling data visibility and lifetime.',
      subtopic: 'Core concepts',
    },
    {
      id: 'q-2',
      question: `In ${topic}, encapsulation refers to:`,
      options: ['A) Hiding implementation details', 'B) Copying code blocks', 'C) Running code faster', 'D) Adding documentation'],
      correctIndex: 0,
      explanation: 'Encapsulation hides internal implementation details, exposing only a clean public interface.',
      subtopic: 'OOP principles',
    },
    {
      id: 'q-3',
      question: `Which best practice is most critical when working with ${topic}?`,
      options: ['A) Write long monolithic functions', 'B) Avoid comments', 'C) Single responsibility principle', 'D) Use only global state'],
      correctIndex: 2,
      explanation: 'Single responsibility ensures each component does one thing well, making code easier to test and maintain.',
      subtopic: 'Best practices',
    },
    {
      id: 'q-4',
      question: `What is the most common beginner mistake in ${topic}?`,
      options: ['A) Over-engineering solutions', 'B) Writing comments', 'C) Testing code regularly', 'D) Using modular design'],
      correctIndex: 0,
      explanation: 'Over-engineering adds unnecessary complexity before understanding fundamentals, slowing progress.',
      subtopic: 'Common pitfalls',
    },
  ].slice(0, count).map((q, i) => ({ ...q, id: `q-${i}` }))

  const raw = await generateModelText({
    model,
    instruction,
    systemMessage: 'You are an expert educator. Respond with pure valid JSON only, absolutely no markdown or extra text.',
    temperature: 0.7,
    mockResponse: JSON.stringify(mockData),
  })

  try {
    const cleaned = raw.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
    const parsed = JSON.parse(cleaned) as unknown[]
    const questions = parsed
      .filter((q): q is Record<string, unknown> => typeof q === 'object' && q !== null)
      .slice(0, count)
      .map((q, index): QuizQuestion => ({
        id: `q-${index}`,
        question: String(q['question'] ?? ''),
        options: Array.isArray(q['options']) ? q['options'].map(String) : [],
        correctIndex: typeof q['correctIndex'] === 'number' ? q['correctIndex'] : 0,
        explanation: String(q['explanation'] ?? ''),
        subtopic: String(q['subtopic'] ?? topic),
      }))
      .filter((q) => q.question.length > 0 && q.options.length >= 2)
    return { questions, topic: summarizeText(topic, 80), difficulty }
  } catch {
    return { questions: mockData, topic, difficulty }
  }
}
