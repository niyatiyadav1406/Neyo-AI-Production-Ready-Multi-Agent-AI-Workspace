import { generateModelText, getModelConfig } from '../assistant/shared'

type Params = {
  topic: string
  weakTopics: string[]
  level: 'beginner' | 'intermediate' | 'advanced'
  score: number
  modelId?: string
}

export type StudyItem = {
  title: string
  description: string
  duration: string
  priority: 'high' | 'medium' | 'low'
  resources: string[]
}

export type StudyPlanResult = {
  plan: StudyItem[]
  summary: string
  estimatedHours: number
  nextSteps: string[]
}

export default async function generateStudyPlan(
  req: { params: Params },
): Promise<StudyPlanResult> {
  const { topic, weakTopics, level, score, modelId } = req.params
  const model = getModelConfig(modelId)
  const weakList = weakTopics.length > 0 ? weakTopics.join(', ') : 'general concepts'

  const instruction = `Create a personalized study plan for someone learning "${topic}".

Context:
- Quiz score: ${score}/100
- Weak areas needing improvement: ${weakList}
- Current level: ${level}

Return ONLY valid JSON (no markdown, no extra text):
{
  "plan": [
    {
      "title": "...",
      "description": "...",
      "duration": "45 minutes",
      "priority": "high",
      "resources": ["Resource name 1", "Resource name 2"]
    }
  ],
  "summary": "One concise sentence describing the overall plan focus.",
  "estimatedHours": 6,
  "nextSteps": ["Immediate action 1", "Action 2", "Action 3"]
}

Requirements:
- Include 4-6 study items, prioritizing the weak areas
- priority must be exactly one of: "high", "medium", "low"
- estimatedHours is a number (total across all items)
- nextSteps has 3 immediate actionable items
- Tailor difficulty to ${level} level`

  const mockPlan: StudyPlanResult = {
    plan: [
      {
        title: `${topic} Fundamentals Intensive`,
        description: `Deep dive into ${weakList}, starting from first principles with worked examples.`,
        duration: '1 hour',
        priority: 'high',
        resources: [`Official ${topic} documentation`, `${topic} crash course on YouTube`],
      },
      {
        title: 'Hands-on Practice Exercises',
        description: 'Solve progressively harder exercises to build muscle memory and reinforce concepts.',
        duration: '1.5 hours',
        priority: 'high',
        resources: ['LeetCode', 'Exercism.io', 'HackerRank'],
      },
      {
        title: 'Structured Video Course',
        description: `Follow a structured ${level} course covering all core ${topic} topics systematically.`,
        duration: '3 hours',
        priority: 'medium',
        resources: ['Udemy', 'Coursera', 'FreeCodeCamp'],
      },
      {
        title: 'Build a Real Project',
        description: `Apply everything learned by building a complete ${topic} project from scratch.`,
        duration: '4 hours',
        priority: 'medium',
        resources: ['GitHub', 'CodeSandbox', 'personal portfolio'],
      },
      {
        title: 'Community & Peer Review',
        description: 'Get feedback on your code from experienced developers and learn from others.',
        duration: '30 minutes',
        priority: 'low',
        resources: ['Stack Overflow', 'Reddit r/learnprogramming', 'Discord communities'],
      },
    ],
    summary: `Focus on ${weakList} through structured practice and project-based learning to solidify your ${topic} foundation.`,
    estimatedHours: 10,
    nextSteps: [
      `Read the official ${topic} documentation for the weak areas`,
      'Set up a daily 30-minute practice schedule',
      'Join an online community to get feedback on your progress',
    ],
  }

  const raw = await generateModelText({
    model,
    instruction,
    systemMessage: 'You are an expert learning coach. Respond only with valid JSON, no markdown.',
    temperature: 0.6,
    mockResponse: JSON.stringify(mockPlan),
  })

  try {
    const cleaned = raw.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
    const parsed = JSON.parse(cleaned) as Record<string, unknown>
    const plan = Array.isArray(parsed['plan'])
      ? (parsed['plan'] as Record<string, unknown>[]).map((item) => ({
          title: String(item['title'] ?? ''),
          description: String(item['description'] ?? ''),
          duration: String(item['duration'] ?? '1 hour'),
          priority: (['high', 'medium', 'low'].includes(String(item['priority'])) ? item['priority'] : 'medium') as StudyItem['priority'],
          resources: Array.isArray(item['resources']) ? item['resources'].map(String) : [],
        }))
      : mockPlan.plan
    return {
      plan,
      summary: String(parsed['summary'] ?? mockPlan.summary),
      estimatedHours: typeof parsed['estimatedHours'] === 'number' ? parsed['estimatedHours'] : mockPlan.estimatedHours,
      nextSteps: Array.isArray(parsed['nextSteps']) ? parsed['nextSteps'].map(String) : mockPlan.nextSteps,
    }
  } catch {
    return mockPlan
  }
}
