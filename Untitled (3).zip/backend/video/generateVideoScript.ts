import { generateModelText, getModelConfig } from '../assistant/shared'

type Params = {
  prompt: string
  style?: 'cinematic' | 'educational' | 'animated' | 'documentary'
  duration?: string
}

export type VideoScene = {
  sceneNumber: number
  title: string
  duration: string
  visualDescription: string
  narration: string
  cameraAngle: string
  mood: string
}

export type VideoScript = {
  title: string
  style: string
  totalDuration: string
  hook: string
  scenes: VideoScene[]
  callToAction: string
}

const MOCK_SCRIPT: VideoScript = {
  title: 'Untitled Video',
  style: 'cinematic',
  totalDuration: '60s',
  hook: 'A stunning visual journey begins here.',
  scenes: [
    { sceneNumber: 1, title: 'Opening', duration: '10s', visualDescription: 'Wide aerial shot establishing the scene.', narration: 'Welcome to this visual story.', cameraAngle: 'Aerial shot', mood: 'Energetic' },
    { sceneNumber: 2, title: 'Rising Action', duration: '15s', visualDescription: 'Medium shot showing key subject in detail.', narration: 'The story unfolds before us.', cameraAngle: 'Medium shot', mood: 'Dramatic' },
    { sceneNumber: 3, title: 'Climax', duration: '20s', visualDescription: 'Close-up capturing raw emotion and detail.', narration: 'At the heart of it all…', cameraAngle: 'Close-up', mood: 'Thrilling' },
    { sceneNumber: 4, title: 'Resolution', duration: '15s', visualDescription: 'Wide shot pulling back to reveal full context.', narration: 'And so the journey comes to an end.', cameraAngle: 'Wide shot', mood: 'Calm' },
  ],
  callToAction: 'Subscribe for more incredible content.',
}

export default async function generateVideoScript(req: { params: Params }) {
  const { prompt, style = 'cinematic', duration = '60s' } = req.params
  const model = getModelConfig()

  const instruction = `Create a ${style} video script for: "${prompt}"
Target duration: ${duration}

Return a JSON object with this exact structure (no markdown, pure JSON):
{
  "title": "Video title",
  "style": "${style}",
  "totalDuration": "${duration}",
  "hook": "Opening hook sentence that grabs attention",
  "scenes": [
    {
      "sceneNumber": 1,
      "title": "Scene title",
      "duration": "10s",
      "visualDescription": "Detailed visual description of what viewers see",
      "narration": "What the narrator/character says",
      "cameraAngle": "Wide shot / Close-up / Aerial / etc.",
      "mood": "Energetic / Mysterious / Calm / etc."
    }
  ],
  "callToAction": "Ending call to action"
}

Generate 4-6 scenes. Make it vivid, engaging, and professional.`

  const raw = await generateModelText({
    model,
    instruction,
    systemMessage: 'You are a professional video scriptwriter. Respond with pure valid JSON only, no markdown or extra text.',
    temperature: 0.8,
    mockResponse: JSON.stringify(MOCK_SCRIPT),
  })

  try {
    const cleaned = raw.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
    return JSON.parse(cleaned) as VideoScript
  } catch {
    return MOCK_SCRIPT
  }
}
