import { createLogger } from '../shared/logger'
import { enforceRateLimit, RateLimitError } from '../shared/rateLimiter'
import { assertValid, validateString, ValidationError } from '../shared/validate'
import {
  generateModelText,
  getLanguageForLocale,
  getModelConfig,
  guessLocaleFromText,
  summarizeText,
  type ProviderId,
} from './shared'

type Params = {
  prompt: string
  modelId?: string
  provider?: ProviderId
}

type ImagePromptPayload = {
  prompt: string
  detectedLanguage: string
  detectedLocale: string
  provider: ProviderId
  modelId: string
  providerLabel: string
  isMockProvider: boolean
}

function buildInstruction(prompt: string): string {
  return [
    'Turn the user idea into a polished AI image generation prompt.',
    'Include subject, composition, lighting, mood, colors, camera feel, environment, and detail level.',
    'Keep it vivid, specific, and production-ready for models like Flux or DALL-E.',
    `User idea: ${prompt}`,
    'Return only the final image generation prompt — no extra commentary.',
  ].join('\n\n')
}

function buildMockPrompt(prompt: string): string {
  return [
    summarizeText(prompt, 180),
    'cinematic composition, dramatic natural lighting, rich color harmony, ultra-detailed textures, polished concept art, high visual clarity, photorealistic quality',
  ].join(', ')
}

export default async function imagePrompt(req: {
  params: Params
  user: User
}): Promise<ImagePromptPayload> {
  const log = createLogger('imagePrompt')
  const elapsed = log.startTimer()

  try {
    // ── Rate limiting ───────────────────────────────────────────────────────
    enforceRateLimit(req.user.sid || req.user.email || 'anonymous', { limit: 20, windowMs: 60_000 })

    // ── Input validation ────────────────────────────────────────────────────
    const prompt = assertValid(validateString(req.params.prompt, 'prompt', { required: false, maxLen: 4_000 }))

    const model = getModelConfig(req.params.modelId)
    const detectedLocale = guessLocaleFromText(prompt || 'Hello')
    const detectedLanguage = getLanguageForLocale(detectedLocale)

    log.info('Request received', { model: model.id, promptLen: prompt.length })

    if (!prompt) {
      log.info('Empty prompt — returning empty payload', { durationMs: elapsed() })
      return {
        prompt: '',
        detectedLanguage,
        detectedLocale,
        provider: model.provider,
        modelId: model.id,
        providerLabel: model.providerLabel,
        isMockProvider: model.isMock,
      }
    }

    const generatedPrompt = await generateModelText({
      model,
      instruction: buildInstruction(prompt),
      systemMessage: 'You write excellent prompts for AI image generation. Output only the final prompt — one paragraph, no bullet points.',
      temperature: 0.7,
      mockResponse: buildMockPrompt(prompt),
    })

    log.info('Request completed', { durationMs: elapsed(), mock: model.isMock })

    return {
      prompt: generatedPrompt,
      detectedLanguage,
      detectedLocale,
      provider: model.provider,
      modelId: model.id,
      providerLabel: model.providerLabel,
      isMockProvider: model.isMock,
    }
  } catch (err) {
    if (err instanceof RateLimitError) {
      log.warn('Rate limit exceeded', { retryAfter: err.retryAfter, durationMs: elapsed() })
      throw err
    }
    if (err instanceof ValidationError) {
      log.warn('Validation failed', { error: err.message, durationMs: elapsed() })
      throw err
    }
    log.error('Unexpected error', { error: String(err), durationMs: elapsed() })
    throw err
  }
}
