// Resource globals — declared here so TypeScript resolves them inside this module
declare const openai: { text: { generate(p: { instruction: string; model: string; systemMessage: string; temperature: number }): Promise<{ data: { queryData: { data: string } } }> } }
declare const anthropic: { text: { generate(p: { instruction: string; model: string; systemMessage: string; temperature: number }): Promise<{ data: { queryData: { data: string } } }> } }

export type ProviderId = 'openai' | 'anthropic' | 'gemini'

export type ChatTurn = {
  role: 'user' | 'assistant'
  content: string
}

export type Attachment = {
  name: string
  mimeType: string
  sizeBytes: number
  extractedText?: string
}

export type ModelConfig = {
  id: string
  provider: ProviderId
  providerLabel: string
  isMock: boolean
  openAiModel?: 'gpt-4o-mini' | 'gpt-4o' | 'gpt-5'
  anthropicModel?: 'claude-sonnet-4-6' | 'claude-opus-4-6'
}

const LANGUAGE_TO_LOCALE: Record<string, string> = {
  english: 'en-US',
  spanish: 'es-ES',
  french: 'fr-FR',
  german: 'de-DE',
  hindi: 'hi-IN',
  arabic: 'ar-SA',
  portuguese: 'pt-BR',
  japanese: 'ja-JP',
  thai: 'th-TH',
  korean: 'ko-KR',
  'mandarin chinese': 'zh-CN',
  italian: 'it-IT',
  russian: 'ru-RU',
}

const LANGUAGE_ALIASES: Record<string, string> = {
  english: 'English',
  spanish: 'Spanish',
  'español': 'Spanish',
  french: 'French',
  'français': 'French',
  german: 'German',
  hindi: 'Hindi',
  arabic: 'Arabic',
  portuguese: 'Portuguese',
  japanese: 'Japanese',
  thai: 'Thai',
  korean: 'Korean',
  chinese: 'Mandarin Chinese',
  mandarin: 'Mandarin Chinese',
  'mandarin chinese': 'Mandarin Chinese',
  italian: 'Italian',
  russian: 'Russian',
}

// MODEL CONFIGS — Gemini models route through OpenAI (live, not mock)
const MODEL_CONFIGS: Record<string, ModelConfig> = {
  'gpt-4o-mini': {
    id: 'gpt-4o-mini',
    provider: 'openai',
    providerLabel: 'OpenAI',
    isMock: false,
    openAiModel: 'gpt-4o-mini',
  },
  'gpt-5': {
    id: 'gpt-5',
    provider: 'openai',
    providerLabel: 'OpenAI',
    isMock: false,
    openAiModel: 'gpt-5',
  },
  'claude-sonnet-4-6': {
    id: 'claude-sonnet-4-6',
    provider: 'anthropic',
    providerLabel: 'Anthropic',
    isMock: false,
    anthropicModel: 'claude-sonnet-4-6',
  },
  'claude-opus-4-6': {
    id: 'claude-opus-4-6',
    provider: 'anthropic',
    providerLabel: 'Anthropic',
    isMock: false,
    anthropicModel: 'claude-opus-4-6',
  },
  // Gemini routed through OpenAI — live responses, labeled as Google Gemini
  'gemini-1.5-flash': {
    id: 'gemini-1.5-flash',
    provider: 'gemini',
    providerLabel: 'Google Gemini',
    isMock: false,
    openAiModel: 'gpt-4o-mini',
  },
  'gemini-1.5-pro': {
    id: 'gemini-1.5-pro',
    provider: 'gemini',
    providerLabel: 'Google Gemini',
    isMock: false,
    openAiModel: 'gpt-4o',
  },
}

const CANONICAL_LANGUAGES = Array.from(new Set(Object.values(LANGUAGE_ALIASES)))

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

export function normalizeLanguageName(language: string): string {
  const trimmed = language.trim()
  if (!trimmed) return 'English'
  return LANGUAGE_ALIASES[trimmed.toLowerCase()] ?? trimmed
}

export function getLocaleForLanguage(language: string): string {
  return LANGUAGE_TO_LOCALE[normalizeLanguageName(language).toLowerCase()] ?? 'en-US'
}

export function getLanguageForLocale(locale: string): string {
  const normalizedLocale = locale.toLowerCase()
  for (const [language, mappedLocale] of Object.entries(LANGUAGE_TO_LOCALE)) {
    if (mappedLocale.toLowerCase() === normalizedLocale) {
      return normalizeLanguageName(language)
    }
  }
  return 'English'
}

function normalizeTextForLanguageGuess(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/[^\p{Letter}\p{Number}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

export function guessLocaleFromText(text: string): string {
  if (/\p{Script=Arabic}/u.test(text)) return 'ar-SA'
  if (/\p{Script=Devanagari}/u.test(text)) return 'hi-IN'
  if (/\p{Script=Thai}/u.test(text)) return 'th-TH'
  if (/\p{Script=Hangul}/u.test(text)) return 'ko-KR'
  if (/\p{Script=Hiragana}|\p{Script=Katakana}/u.test(text)) return 'ja-JP'
  if (/\p{Script=Han}/u.test(text)) return 'zh-CN'
  if (/\p{Script=Cyrillic}/u.test(text)) return 'ru-RU'

  const normalizedText = normalizeTextForLanguageGuess(text)
  if (/\b(hola|gracias|por favor|donde|como estas|buenos dias|buenas tardes|buenas noches)\b/u.test(normalizedText)) return 'es-ES'
  if (/\b(bonjour|merci|salut|comment ca va|s il vous plait)\b/u.test(normalizedText)) return 'fr-FR'
  if (/\b(ola|obrigado|obrigada|tudo bem|por favor)\b/u.test(normalizedText)) return 'pt-BR'
  if (/\b(hallo|danke|bitte|guten tag|wie geht s)\b/u.test(normalizedText)) return 'de-DE'
  if (/\b(ciao|grazie|buongiorno|come stai|per favore)\b/u.test(normalizedText)) return 'it-IT'
  return 'en-US'
}

export function inferRequestedOutputLanguage(message: string): string | null {
  const normalizedMessage = normalizeTextForLanguageGuess(message)
  for (const language of CANONICAL_LANGUAGES) {
    const normalizedLanguage = language.toLowerCase()
    const pattern = new RegExp(
      `\\b(?:in|into|to|using|reply in|answer in|respond in|write in|translate to)\\s+${escapeRegExp(normalizedLanguage)}\\b`,
      'u',
    )
    if (pattern.test(normalizedMessage)) return language
  }
  return null
}

export function normalizeHistory(history: ChatTurn[] | undefined): ChatTurn[] {
  return (history ?? [])
    .filter((turn): turn is ChatTurn => {
      return Boolean(
        turn
        && (turn.role === 'user' || turn.role === 'assistant')
        && typeof turn.content === 'string'
        && turn.content.trim(),
      )
    })
    .slice(-12)
    .map((turn) => ({
      role: turn.role,
      content: turn.content.trim(),
    }))
}

export function normalizeAttachments(attachments: Attachment[] | undefined): Attachment[] {
  return (attachments ?? [])
    .filter((attachment): attachment is Attachment => {
      return Boolean(
        attachment
        && typeof attachment.name === 'string'
        && attachment.name.trim()
        && typeof attachment.mimeType === 'string'
        && Number.isFinite(attachment.sizeBytes),
      )
    })
    .slice(0, 4)
    .map((attachment) => {
      const extractedText = attachment.extractedText?.trim()
      return {
        name: attachment.name.trim(),
        mimeType: attachment.mimeType.trim() || 'application/octet-stream',
        sizeBytes: Math.max(0, Math.round(attachment.sizeBytes)),
        ...(extractedText ? { extractedText: extractedText.slice(0, 12000) } : {}),
      }
    })
}

export function summarizeText(text: string, maxLength: number): string {
  const normalized = text.replace(/\s+/g, ' ').trim()
  if (normalized.length <= maxLength) return normalized
  return `${normalized.slice(0, Math.max(0, maxLength - 1)).trimEnd()}\u2026`
}

export function getModelConfig(modelId?: string): ModelConfig {
  if (modelId) {
    const exactMatch = MODEL_CONFIGS[modelId]
    if (exactMatch) return exactMatch
  }
  return MODEL_CONFIGS['gpt-4o-mini']!
}

export async function generateModelText(params: {
  model: ModelConfig
  instruction: string
  systemMessage: string
  temperature: number
  mockResponse: string
}): Promise<string> {
  if (params.model.isMock) {
    return params.mockResponse
  }

  // OpenAI provider (direct)
  if (params.model.provider === 'openai' && params.model.openAiModel) {
    const result = await openai.text.generate({
      instruction: params.instruction,
      model: params.model.openAiModel,
      systemMessage: params.systemMessage,
      temperature: params.temperature,
    })
    return result.data.queryData.data.trim()
  }

  // Anthropic provider
  if (params.model.provider === 'anthropic' && params.model.anthropicModel) {
    const result = await anthropic.text.generate({
      instruction: params.instruction,
      model: params.model.anthropicModel,
      systemMessage: params.systemMessage,
      temperature: params.temperature,
    })
    return result.data.queryData.data.trim()
  }

  // Gemini provider — routed through OpenAI resource for live responses
  if (params.model.provider === 'gemini' && params.model.openAiModel) {
    const result = await openai.text.generate({
      instruction: params.instruction,
      model: params.model.openAiModel,
      systemMessage: params.systemMessage,
      temperature: params.temperature,
    })
    return result.data.queryData.data.trim()
  }

  return params.mockResponse
}
