import { createLogger } from '../shared/logger'
import { enforceRateLimit, RateLimitError } from '../shared/rateLimiter'
import { assertValid, validateString, ValidationError } from '../shared/validate'
import {
  generateModelText,
  getLanguageForLocale,
  getLocaleForLanguage,
  getModelConfig,
  guessLocaleFromText,
  inferRequestedOutputLanguage,
  normalizeAttachments,
  normalizeHistory,
  summarizeText,
  type Attachment,
  type ChatTurn,
  type ProviderId,
} from './shared'

type Params = {
  message: string
  language?: string
  history?: ChatTurn[]
  attachments?: Attachment[]
  modelId?: string
  provider?: ProviderId
}

type ReplyPayload = {
  reply: string
  detectedLanguage: string
  detectedLocale: string
  sourceLanguage: string
  sourceLocale: string
  targetLanguage: string
  targetLocale: string
  sourceText: string
  provider: ProviderId
  modelId: string
  providerLabel: string
  isMockProvider: boolean
}

function buildAssistantPrompt(params: {
  message: string
  targetLanguage: string
  history: ChatTurn[]
  attachments: Attachment[]
}): string {
  const historySummary = params.history.length > 0
    ? params.history.map((turn) => `${turn.role.toUpperCase()}: ${turn.content}`).join('\n')
    : 'No prior conversation.'
  const attachmentSummary = params.attachments.length > 0
    ? params.attachments
        .map((a) => {
          const text = a.extractedText
            ? ` Extracted text: ${summarizeText(a.extractedText, 900)}`
            : ''
          return `- ${a.name} (${a.mimeType}, ${a.sizeBytes} bytes).${text}`
        })
        .join('\n')
    : 'No attachments.'

  return [
    `Reply in ${params.targetLanguage}.`,
    'You are one capable assistant that can answer questions, summarize files, explain ideas, draft content, help with code, and translate when the user asks.',
    'Be clear, helpful, direct, and easy to understand.',
    `Latest user message: ${params.message}`,
    `Conversation history:\n${historySummary}`,
    `Attachments:\n${attachmentSummary}`,
  ].join('\n\n')
}

function buildMockReply(params: {
  message: string
  targetLanguage: string
  history: ChatTurn[]
  attachments: Attachment[]
  providerLabel: string
}): string {
  const historySummary = params.history.length > 0
    ? `Conversation context included ${params.history.length} prior turn(s).`
    : 'This appears to be a new conversation.'
  const attachmentSummary = params.attachments.length === 0
    ? 'No attachments were provided.'
    : `Attachments noted: ${params.attachments.map((a) => a.name).join(', ')}.`

  return [
    `This is a mock ${params.providerLabel} answer in ${params.targetLanguage}.`,
    `I understood your request as: "${summarizeText(params.message, 220)}".`,
    historySummary,
    attachmentSummary,
    'You can ask for code, translations, explanations, summaries, or structured help in one chat.',
  ].join(' ')
}

export default async function reply(req: {
  params: Params
  user: User
}): Promise<ReplyPayload> {
  const log = createLogger('reply')
  const elapsed = log.startTimer()

  try {
    // ── Rate limiting ───────────────────────────────────────────────────────
    const rateLimitKey = req.user.sid || req.user.email || 'anonymous'
    enforceRateLimit(rateLimitKey, { limit: 30, windowMs: 60_000 })

    // ── Input validation ────────────────────────────────────────────────────
    const rawMessage = assertValid(
      validateString(req.params.message, 'message', { required: false, maxLen: 10_000 }),
    )
    const history = normalizeHistory(req.params.history)
    const attachments = normalizeAttachments(req.params.attachments)
    const hasAttachments = attachments.length > 0
    const message = rawMessage || (hasAttachments ? 'Please review the attached files and help the user.' : '')

    const model = getModelConfig(req.params.modelId)
    const detectedLocale = guessLocaleFromText(message || 'Hello')
    const detectedLanguage = getLanguageForLocale(detectedLocale)
    const inferredLanguage = inferRequestedOutputLanguage(message)
    const targetLanguage = req.params.language?.trim() || inferredLanguage || detectedLanguage || 'English'
    const targetLocale = getLocaleForLanguage(targetLanguage)

    log.info('Request received', {
      model: model.id,
      provider: model.provider,
      messageLen: message.length,
      historyTurns: history.length,
      attachments: attachments.length,
      targetLanguage,
    })

    if (!message) {
      log.info('Empty message — returning prompt', { durationMs: elapsed() })
      return {
        reply: `Ask me anything in ${targetLanguage}.`,
        detectedLanguage: 'English',
        detectedLocale: 'en-US',
        sourceLanguage: 'English',
        sourceLocale: 'en-US',
        targetLanguage,
        targetLocale,
        sourceText: '',
        provider: model.provider,
        modelId: model.id,
        providerLabel: model.providerLabel,
        isMockProvider: model.isMock,
      }
    }

    const replyText = await generateModelText({
      model,
      instruction: buildAssistantPrompt({ message, targetLanguage, history, attachments }),
      systemMessage: 'You are a helpful all-purpose AI assistant. Keep answers concise, clear, and useful.',
      temperature: 0.5,
      mockResponse: buildMockReply({ message, targetLanguage, history, attachments, providerLabel: model.providerLabel }),
    })

    log.info('Request completed', { durationMs: elapsed(), provider: model.provider, mock: model.isMock })

    return {
      reply: replyText,
      detectedLanguage,
      detectedLocale,
      sourceLanguage: detectedLanguage,
      sourceLocale: getLocaleForLanguage(detectedLanguage),
      targetLanguage,
      targetLocale,
      sourceText: message,
      provider: model.provider,
      modelId: model.id,
      providerLabel: model.providerLabel,
      isMockProvider: model.isMock,
    }
  } catch (err) {
    if (err instanceof RateLimitError) {
      log.warn('Rate limit exceeded', { retryAfter: err.retryAfter, durationMs: elapsed() })
      throw err
    }
    if (err instanceof ValidationError) {
      log.warn('Validation failed', { error: err.message, durationMs: elapsed() })
      throw err
    }
    log.error('Unexpected error', { error: String(err), durationMs: elapsed() })
    throw err
  }
}
