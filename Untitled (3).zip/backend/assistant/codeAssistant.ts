import { createLogger } from '../shared/logger'
import { enforceRateLimit, RateLimitError } from '../shared/rateLimiter'
import { assertValid, validateString, ValidationError } from '../shared/validate'
import {
  generateModelText,
  getLanguageForLocale,
  getModelConfig,
  guessLocaleFromText,
  inferRequestedOutputLanguage,
  summarizeText,
  type ProviderId,
} from './shared'

type Params = {
  prompt: string
  language: string
  modelId?: string
  provider?: ProviderId
}

type CodeAssistantPayload = {
  result: string
  language: string
  detectedLanguage: string
  detectedLocale: string
  provider: ProviderId
  modelId: string
  providerLabel: string
  isMockProvider: boolean
}

function buildPrompt(params: { prompt: string; language: string }): string {
  return [
    `Programming language or stack: ${params.language}`,
    'Write complete, production-ready code based on the user description.',
    'Always output the full implementation — no placeholders, no TODOs, no stubs.',
    'Include helpful inline comments where the logic benefits from explanation.',
    'Return only the code, optionally followed by a short usage example.',
    `User description: ${params.prompt}`,
  ].join('\n\n')
}

function buildMockResult(params: {
  prompt: string
  language: string
  providerLabel: string
}): string {
  const summarizedPrompt = summarizeText(params.prompt, 180)
  return [
    `// Mock ${params.providerLabel} code writer output (${params.language})`,
    `// Request: "${summarizedPrompt}"`,
    `// Connect a live AI resource to receive actual generated code.`,
    `function example() {`,
    `  // Implementation will appear here once a live model is connected.`,
    `  return null`,
    `}`,
  ].join('\n')
}

export default async function codeAssistant(req: {
  params: Params
  user: User
}): Promise<CodeAssistantPayload> {
  const log = createLogger('codeAssistant')
  const elapsed = log.startTimer()

  try {
    // ── Rate limiting ───────────────────────────────────────────────────────
    enforceRateLimit(req.user.sid || req.user.email || 'anonymous', { limit: 20, windowMs: 60_000 })

    // ── Input validation ────────────────────────────────────────────────────
    const prompt = assertValid(validateString(req.params.prompt, 'prompt', { required: false, maxLen: 8_000 }))
    const requestedLanguage = assertValid(validateString(req.params.language, 'language', { required: true, maxLen: 64 }))

    const model = getModelConfig(req.params.modelId)
    const detectedLocale = guessLocaleFromText(prompt || 'Hello')
    const detectedLanguage = getLanguageForLocale(detectedLocale)
    const outputLanguage = inferRequestedOutputLanguage(prompt) ?? detectedLanguage

    log.info('Request received', { model: model.id, language: requestedLanguage, promptLen: prompt.length })

    if (!prompt) {
      log.info('Empty prompt — returning hint', { durationMs: elapsed() })
      return {
        result: 'Describe the code you want written and click Write code.',
        language: requestedLanguage,
        detectedLanguage,
        detectedLocale,
        provider: model.provider,
        modelId: model.id,
        providerLabel: model.providerLabel,
        isMockProvider: model.isMock,
      }
    }

    const result = await generateModelText({
      model,
      instruction: buildPrompt({ prompt, language: requestedLanguage }),
      systemMessage: `You are an expert code writer. Write in ${outputLanguage}. Output complete, clean, runnable code only — no placeholders.`,
      temperature: 0.25,
      mockResponse: buildMockResult({ prompt, language: requestedLanguage, providerLabel: model.providerLabel }),
    })

    log.info('Request completed', { durationMs: elapsed(), mock: model.isMock })

    return {
      result,
      language: requestedLanguage,
      detectedLanguage,
      detectedLocale,
      provider: model.provider,
      modelId: model.id,
      providerLabel: model.providerLabel,
      isMockProvider: model.isMock,
    }
  } catch (err) {
    if (err instanceof RateLimitError) {
      log.warn('Rate limit exceeded', { retryAfter: err.retryAfter, durationMs: elapsed() })
      throw err
    }
    if (err instanceof ValidationError) {
      log.warn('Validation failed', { error: err.message, durationMs: elapsed() })
      throw err
    }
    log.error('Unexpected error', { error: String(err), durationMs: elapsed() })
    throw err
  }
}
