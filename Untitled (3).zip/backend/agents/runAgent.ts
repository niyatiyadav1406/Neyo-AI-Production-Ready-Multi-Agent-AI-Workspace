import { generateModelText, getModelConfig } from '../assistant/shared'

export type AgentType = 'research' | 'design' | 'code' | 'review' | 'test'

type Params = {
  agentType: AgentType
  task: string
  context: string
  modelId?: string
}

export type RunAgentResult = {
  agentType: AgentType
  agentName: string
  output: string
  keyPoints: string[]
}

type AgentConfig = {
  name: string
  emoji: string
  systemMessage: string
  buildInstruction: (task: string, context: string) => string
  mockOutput: string
}

const AGENTS: Record<AgentType, AgentConfig> = {
  research: {
    name: 'Research Agent',
    emoji: '🔍',
    systemMessage: 'You are a thorough research agent. Analyze the task, identify key concepts, technologies, and approaches.',
    buildInstruction: (task, _ctx) =>
      `Research this task thoroughly and provide structured findings:\n\nTask: ${task}\n\nProvide:\n1. Key concepts and technologies involved\n2. Recommended approaches and patterns\n3. Potential challenges and mitigations\n4. Relevant tools, libraries, or frameworks\n\nBe specific and actionable.`,
    mockOutput:
      '## Research Findings\n\n**Key Technologies:** React, TypeScript, Node.js, REST APIs\n\n**Recommended Approaches:**\n- Component-based architecture with clear separation of concerns\n- RESTful API design with proper HTTP methods\n- State management using React hooks (useState, useReducer)\n\n**Potential Challenges:**\n- State synchronization between components → use Context or Zustand\n- Performance with large datasets → implement pagination and memoization\n- Error handling → implement error boundaries and global error handler\n\n**Recommended Tools:**\n- Vite for build tooling\n- React Query for data fetching\n- Zod for schema validation',
  },
  design: {
    name: 'Design Agent',
    emoji: '📐',
    systemMessage: 'You are an experienced software architect. Create clear, practical system designs based on research findings.',
    buildInstruction: (task, ctx) =>
      `Design a solution architecture for this task.\n\nTask: ${task}\n\nResearch context:\n${ctx}\n\nProvide:\n1. High-level architecture overview\n2. Component/module breakdown\n3. Data models and API contracts\n4. Technology choices with rationale\n5. Folder/file structure\n\nBe precise and implementable.`,
    mockOutput:
      '## Architecture Design\n\n**Architecture:** Client-Server SPA with RESTful backend\n\n**Components:**\n```\nsrc/\n├── components/     # Reusable UI components\n├── pages/          # Route-level page components\n├── hooks/          # Custom React hooks\n├── services/       # API call functions\n├── types/          # TypeScript type definitions\n└── utils/          # Helper functions\n```\n\n**Data Models:**\n```typescript\ntype User = { id: string; name: string; email: string }\ntype Task = { id: string; title: string; status: \'pending\' | \'done\' }\n```\n\n**API Contracts:**\n- GET /api/tasks → Task[]\n- POST /api/tasks → Task\n- PATCH /api/tasks/:id → Task\n\n**Tech Stack:** React + TypeScript, Express, PostgreSQL, Zod validation',
  },
  code: {
    name: 'Coding Agent',
    emoji: '💻',
    systemMessage: 'You are an expert programmer. Write clean, production-quality code with proper error handling, types, and comments.',
    buildInstruction: (task, ctx) =>
      `Implement the solution for this task.\n\nTask: ${task}\n\nDesign specification:\n${ctx}\n\nProvide:\n1. Core implementation (complete, runnable code)\n2. Type definitions\n3. Error handling\n4. Brief inline comments for complex logic\n5. Usage example\n\nWrite production-quality TypeScript/React code.`,
    mockOutput:
      '## Implementation\n\n```typescript\nimport { useState, useCallback } from \'react\'\n\ninterface Task {\n  id: string\n  title: string\n  status: \'pending\' | \'done\'\n  createdAt: Date\n}\n\nfunction useTaskManager() {\n  const [tasks, setTasks] = useState<Task[]>([])\n  const [loading, setLoading] = useState(false)\n\n  const addTask = useCallback((title: string) => {\n    if (!title.trim()) throw new Error(\'Title is required\')\n    const task: Task = {\n      id: crypto.randomUUID(),\n      title: title.trim(),\n      status: \'pending\',\n      createdAt: new Date(),\n    }\n    setTasks(prev => [...prev, task])\n    return task\n  }, [])\n\n  const completeTask = useCallback((id: string) => {\n    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: \'done\' } : t))\n  }, [])\n\n  const deleteTask = useCallback((id: string) => {\n    setTasks(prev => prev.filter(t => t.id !== id))\n  }, [])\n\n  return { tasks, loading, addTask, completeTask, deleteTask }\n}\n\nexport default useTaskManager\n```\n\n**Usage:**\n```tsx\nconst { tasks, addTask, completeTask } = useTaskManager()\naddTask(\'Build the feature\')\n```',
  },
  review: {
    name: 'Review Agent',
    emoji: '🔎',
    systemMessage: 'You are a senior code reviewer. Identify bugs, security issues, performance problems, and suggest concrete improvements.',
    buildInstruction: (task, ctx) =>
      `Review this code implementation carefully.\n\nOriginal task: ${task}\n\nCode to review:\n${ctx}\n\nProvide:\n1. Overall quality score (1-10) with justification\n2. Bugs or logical errors found\n3. Security vulnerabilities\n4. Performance concerns\n5. Specific improvement suggestions with corrected code snippets\n\nBe constructive and thorough.`,
    mockOutput:
      '## Code Review\n\n**Overall Score: 8.5/10** — Well-structured with good TypeScript usage.\n\n**Issues Found:**\n\n🔴 **Bug:** Missing null check before calling `.trim()` on user input\n```typescript\n// Fix: add null guard\nconst title = input?.trim() ?? \'\'\nif (!title) throw new Error(\'Title required\')\n```\n\n🟡 **Performance:** `useCallback` dependencies could be optimized — `tasks` not needed in `addTask`\n\n🟡 **Security:** Consider sanitizing task titles to prevent XSS if rendered as HTML\n\n🟢 **Good:** Immutable state updates, proper TypeScript types, clean separation of concerns\n\n**Suggestions:**\n- Add loading state per task for async operations\n- Implement optimistic updates for better UX\n- Add error boundary around the task list component',
  },
  test: {
    name: 'Test Agent',
    emoji: '🧪',
    systemMessage: 'You are a QA expert. Write comprehensive, realistic test suites covering unit tests, edge cases, and integration scenarios.',
    buildInstruction: (task, ctx) =>
      `Write a comprehensive test suite for this implementation.\n\nOriginal task: ${task}\n\nCode to test:\n${ctx}\n\nProvide:\n1. Unit tests for all core functions\n2. Edge case tests (empty input, invalid data, etc.)\n3. Integration test scenarios\n4. Test coverage summary\n\nUse Vitest/Jest syntax with @testing-library/react for component tests.`,
    mockOutput:
      '## Test Suite\n\n```typescript\nimport { describe, it, expect, beforeEach } from \'vitest\'\nimport { renderHook, act } from \'@testing-library/react\'\nimport useTaskManager from \'./useTaskManager\'\n\ndescribe(\'useTaskManager\', () => {\n  describe(\'addTask\', () => {\n    it(\'creates a task with correct properties\', () => {\n      const { result } = renderHook(() => useTaskManager())\n      act(() => { result.current.addTask(\'Test task\') })\n      expect(result.current.tasks).toHaveLength(1)\n      expect(result.current.tasks[0]?.title).toBe(\'Test task\')\n      expect(result.current.tasks[0]?.status).toBe(\'pending\')\n    })\n\n    it(\'throws on empty title\', () => {\n      const { result } = renderHook(() => useTaskManager())\n      expect(() => act(() => { result.current.addTask(\'\') })).toThrow(\'Title is required\')\n    })\n\n    it(\'trims whitespace from title\', () => {\n      const { result } = renderHook(() => useTaskManager())\n      act(() => { result.current.addTask(\'  spaced  \') })\n      expect(result.current.tasks[0]?.title).toBe(\'spaced\')\n    })\n  })\n\n  describe(\'completeTask\', () => {\n    it(\'marks task as done\', () => {\n      const { result } = renderHook(() => useTaskManager())\n      act(() => { result.current.addTask(\'task\') })\n      const id = result.current.tasks[0]?.id ?? \'\'\n      act(() => { result.current.completeTask(id) })\n      expect(result.current.tasks[0]?.status).toBe(\'done\')\n    })\n  })\n})\n```\n\n**Coverage: 94%** — Missing: error boundary integration tests',
  },
}

export default async function runAgent(req: { params: Params }): Promise<RunAgentResult> {
  const { agentType, task, context, modelId } = req.params
  const model = getModelConfig(modelId)
  const config = AGENTS[agentType]

  const output = await generateModelText({
    model,
    instruction: config.buildInstruction(task, context),
    systemMessage: config.systemMessage,
    temperature: 0.5,
    mockResponse: config.mockOutput,
  })

  // Extract key bullet points from output
  const keyPoints = output
    .split('\n')
    .filter((line) => /^[-•*]\s|^\d+\.\s/.test(line.trim()))
    .map((line) => line.replace(/^[-•*\d.]\s+/, '').trim())
    .filter((line) => line.length > 5)
    .slice(0, 4)

  return {
    agentType,
    agentName: config.name,
    output,
    keyPoints: keyPoints.length > 0 ? keyPoints : ['Analysis complete', 'Output ready for next agent'],
  }
}
