/** Input validation helpers for backend serverless functions. */

export type Ok<T> = { ok: true; value: T }
export type Err = { ok: false; error: string }
export type ValidationResult<T> = Ok<T> | Err

// ─── String ────────────────────────────────────────────────────────────────

export function validateString(
  value: unknown,
  field: string,
  opts: {
    required?: boolean
    minLen?: number
    maxLen?: number
  } = {},
): ValidationResult<string> {
  const { required = true, minLen = 0, maxLen = 20_000 } = opts

  if (typeof value !== 'string') {
    if (!required) return { ok: true, value: '' }
    return { ok: false, error: `${field} must be a string.` }
  }

  const trimmed = value.trim()

  if (required && !trimmed) {
    return { ok: false, error: `${field} is required and cannot be empty.` }
  }

  if (trimmed.length < minLen) {
    return { ok: false, error: `${field} must be at least ${minLen} character(s).` }
  }

  if (trimmed.length > maxLen) {
    return { ok: false, error: `${field} must not exceed ${maxLen} characters (got ${trimmed.length}).` }
  }

  return { ok: true, value: trimmed }
}

// ─── Enum ──────────────────────────────────────────────────────────────────

export function validateEnum<T extends string>(
  value: unknown,
  field: string,
  allowed: readonly T[],
  fallback: T,
): ValidationResult<T> {
  if (typeof value !== 'string') return { ok: true, value: fallback }
  if ((allowed as readonly string[]).includes(value)) return { ok: true, value: value as T }
  return { ok: false, error: `${field} must be one of: ${allowed.join(', ')}.` }
}

// ─── Number ────────────────────────────────────────────────────────────────

export function validatePositiveInt(
  value: unknown,
  field: string,
  opts: { max?: number; fallback?: number } = {},
): ValidationResult<number> {
  const { max = 10_000, fallback } = opts
  const n = typeof value === 'number' ? value : Number(value)

  if (!Number.isFinite(n) || n !== Math.floor(n) || n < 0) {
    if (fallback !== undefined) return { ok: true, value: fallback }
    return { ok: false, error: `${field} must be a non-negative integer.` }
  }

  if (n > max) {
    return { ok: false, error: `${field} must not exceed ${max}.` }
  }

  return { ok: true, value: n }
}

// ─── Sanitize ──────────────────────────────────────────────────────────────

/**
 * Escapes HTML special characters to prevent XSS when user input is
 * ever serialised back into markup. Use for untrusted text fields.
 */
export function sanitizeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/`/g, '&#x60;')
}

/** Strip ASCII control characters (except tab / newline / CR). */
export function stripControlChars(value: string): string {
  // eslint-disable-next-line no-control-regex
  return value.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
}

// ─── Error ─────────────────────────────────────────────────────────────────

export class ValidationError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'ValidationError'
  }
}

/**
 * Unwrap a ValidationResult or throw a ValidationError.
 * Convenient for functions that should short-circuit on bad input.
 */
export function assertValid<T>(result: ValidationResult<T>): T {
  if (!result.ok) throw new ValidationError(result.error)
  return result.value
}
