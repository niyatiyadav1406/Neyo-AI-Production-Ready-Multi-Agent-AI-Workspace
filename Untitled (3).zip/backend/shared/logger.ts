/** Structured server-side logger. Emits JSON lines to stdout/stderr. */

type LogLevel = 'debug' | 'info' | 'warn' | 'error'

type LogEntry = {
  timestamp: string
  level: LogLevel
  requestId: string
  fn: string
  message: string
  durationMs?: number
  context?: Record<string, unknown>
}

const LEVEL_RANK: Record<LogLevel, number> = { debug: 0, info: 1, warn: 2, error: 3 }
const MIN_LEVEL: LogLevel = 'info'

function shouldLog(level: LogLevel): boolean {
  return LEVEL_RANK[level] >= LEVEL_RANK[MIN_LEVEL]
}

function emit(entry: LogEntry): void {
  if (!shouldLog(entry.level)) return
  const line = JSON.stringify(entry)
  if (entry.level === 'error' || entry.level === 'warn') {
    console.error(line)
  } else {
    console.log(line)
  }
}

function makeId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

export type Logger = {
  readonly requestId: string
  debug(message: string, context?: Record<string, unknown>): void
  info(message: string, context?: Record<string, unknown>): void
  warn(message: string, context?: Record<string, unknown>): void
  error(message: string, context?: Record<string, unknown>): void
  /** Returns a function that returns elapsed ms since the call to startTimer(). */
  startTimer(): () => number
}

/**
 * Create a request-scoped structured logger.
 * @param fn  Name of the calling backend function (used in every log line).
 */
export function createLogger(fn: string): Logger {
  const requestId = makeId()

  const log = (
    level: LogLevel,
    message: string,
    extras?: Record<string, unknown>,
  ): void => {
    emit({ timestamp: new Date().toISOString(), level, requestId, fn, message, ...(extras ? { context: extras } : {}) })
  }

  return {
    requestId,
    debug: (msg, ctx) => log('debug', msg, ctx),
    info: (msg, ctx) => log('info', msg, ctx),
    warn: (msg, ctx) => log('warn', msg, ctx),
    error: (msg, ctx) => log('error', msg, ctx),
    startTimer: () => {
      const start = Date.now()
      return () => Date.now() - start
    },
  }
}
