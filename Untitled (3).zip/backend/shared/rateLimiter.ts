/**
 * In-memory sliding-window rate limiter.
 *
 * NOTE: Because serverless functions may run in isolated VM contexts this
 * store resets per cold-start, which is intentional for this layer of
 * protection. A persistent counter (e.g. Retool DB) would be needed for
 * hard multi-instance enforcement.
 */

type Window = {
  count: number
  resetAt: number // epoch ms
}

const store = new Map<string, Window>()

// ─── Types ─────────────────────────────────────────────────────────────────

export type RateLimitOk = {
  allowed: true
  /** Remaining requests in the current window. */
  remaining: number
  /** Seconds until the window resets. */
  resetIn: number
}

export type RateLimitDenied = {
  allowed: false
  /** Seconds the caller should wait before retrying. */
  retryAfter: number
}

export type RateLimitResult = RateLimitOk | RateLimitDenied

// ─── Core ──────────────────────────────────────────────────────────────────

/**
 * Check (and record) one request for the given key.
 *
 * @param key       Unique per-caller identifier — typically `user.email` or `user.sid`.
 * @param limit     Max requests allowed per window (default 30).
 * @param windowMs  Window duration in milliseconds (default 60 000 = 1 min).
 */
export function checkRateLimit(
  key: string,
  opts: { limit?: number; windowMs?: number } = {},
): RateLimitResult {
  const { limit = 30, windowMs = 60_000 } = opts
  const now = Date.now()
  const existing = store.get(key)

  if (!existing || now >= existing.resetAt) {
    // Fresh window
    store.set(key, { count: 1, resetAt: now + windowMs })
    return { allowed: true, remaining: limit - 1, resetIn: Math.ceil(windowMs / 1000) }
  }

  if (existing.count >= limit) {
    return {
      allowed: false,
      retryAfter: Math.ceil((existing.resetAt - now) / 1000),
    }
  }

  existing.count += 1
  return {
    allowed: true,
    remaining: limit - existing.count,
    resetIn: Math.ceil((existing.resetAt - now) / 1000),
  }
}

// ─── Convenience ───────────────────────────────────────────────────────────

export class RateLimitError extends Error {
  readonly retryAfter: number

  constructor(retryAfter: number) {
    super(`Rate limit exceeded. Please try again in ${retryAfter} second(s).`)
    this.name = 'RateLimitError'
    this.retryAfter = retryAfter
  }
}

/**
 * Like `checkRateLimit` but throws a `RateLimitError` when the limit is hit.
 * Drop-in one-liner at the top of a backend function:
 *
 * ```ts
 * enforceRateLimit(req.user.sid, { limit: 20, windowMs: 60_000 })
 * ```
 */
export function enforceRateLimit(
  key: string,
  opts?: { limit?: number; windowMs?: number },
): RateLimitOk {
  const result = checkRateLimit(key, opts)
  if (!result.allowed) throw new RateLimitError(result.retryAfter)
  return result
}
