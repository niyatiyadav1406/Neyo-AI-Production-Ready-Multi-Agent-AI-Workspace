import { generateModelText, getModelConfig } from '../assistant/shared'

type Params = {
  question: string
  modelId?: string
}

export type ExplainResult = {
  answer: string
  confidence: number
  reasoning: string[]
  sources: string[]
  alternatives: string[]
  topic: string
  processingMs: number
}

export default async function explain(req: { params: Params }): Promise<ExplainResult> {
  const { question, modelId } = req.params
  const model = getModelConfig(modelId)
  const start = Date.now()

  const instruction = `Answer this question with full transparency and explainability:

Question: "${question}"

Return ONLY valid JSON (absolutely no markdown, no code blocks):
{
  "answer": "Clear, direct, comprehensive answer.",
  "confidence": 85,
  "reasoning": [
    "Step 1: ...",
    "Step 2: ...",
    "Step 3: ...",
    "Step 4: ..."
  ],
  "sources": [
    "Source/knowledge domain 1",
    "Source/knowledge domain 2",
    "Source/knowledge domain 3"
  ],
  "alternatives": [
    "Alternative perspective or approach 1",
    "Alternative perspective or approach 2"
  ],
  "topic": "Main topic category (1-3 words)"
}

Rules:
- confidence is 0-100, be genuinely honest about uncertainty (complex/opinion questions score lower)
- reasoning has 3-5 logical steps showing HOW you arrived at the answer
- sources are knowledge domains, textbooks, or disciplines (not URLs)
- alternatives show genuinely different ways to approach or think about the question
- topic is the academic/professional category this question belongs to`

  const mockResult: ExplainResult = {
    answer: `Based on my analysis of "${question}", here is a comprehensive and well-reasoned answer. This response synthesizes multiple relevant knowledge domains to provide clarity on the subject matter, considering various perspectives and established principles in the field.`,
    confidence: 78,
    reasoning: [
      'Identified the core concept being asked about in the question',
      'Retrieved relevant knowledge from training data across multiple domains',
      'Cross-referenced multiple established sources and frameworks',
      'Applied logical inference to resolve any ambiguities',
      'Formulated a response that balances accuracy with clarity',
    ],
    sources: [
      'Academic textbooks and peer-reviewed literature',
      'Industry documentation and technical standards',
      'Educational curricula and structured learning resources',
    ],
    alternatives: [
      'Empirical approach: derive the answer from first-principles experimentation',
      'Historical approach: trace how thinking on this topic evolved over time',
    ],
    topic: 'General Knowledge',
    processingMs: 0,
  }

  const raw = await generateModelText({
    model,
    instruction,
    systemMessage: 'You are a transparent AI assistant. Always return pure valid JSON only, never markdown.',
    temperature: 0.5,
    mockResponse: JSON.stringify({ ...mockResult, processingMs: undefined }),
  })

  const processingMs = Date.now() - start

  try {
    const cleaned = raw.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
    const parsed = JSON.parse(cleaned) as Record<string, unknown>

    const confidence = typeof parsed['confidence'] === 'number'
      ? Math.min(100, Math.max(0, Math.round(parsed['confidence'])))
      : 75

    return {
      answer: String(parsed['answer'] ?? ''),
      confidence,
      reasoning: Array.isArray(parsed['reasoning']) ? parsed['reasoning'].map(String) : [],
      sources: Array.isArray(parsed['sources']) ? parsed['sources'].map(String) : [],
      alternatives: Array.isArray(parsed['alternatives']) ? parsed['alternatives'].map(String) : [],
      topic: String(parsed['topic'] ?? 'General'),
      processingMs,
    }
  } catch {
    return { ...mockResult, processingMs }
  }
}
